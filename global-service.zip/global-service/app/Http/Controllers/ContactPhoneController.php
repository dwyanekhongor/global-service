<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ContactPhoneController extends Controller
{
    //
}
