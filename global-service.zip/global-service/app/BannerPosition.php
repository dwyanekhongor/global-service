<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BannerPosition extends Model
{
    protected $table = 'banner_position';
}